# Expense_tracker_js

This expense tracker projects - basic mini projects for web development

Skills used: 
 1. JavaScript
 2. HTML5
 3. CSS
 
# Dynamic-container updates
<img width="400" src="https://github.com/Divyathali/expense_tracker_js/blob/main/images/dynamic-updated-containers.png">

# Input fields
<img width="400" src="https://github.com/Divyathali/expense_tracker_js/blob/main/images/input-fileds.png" >

