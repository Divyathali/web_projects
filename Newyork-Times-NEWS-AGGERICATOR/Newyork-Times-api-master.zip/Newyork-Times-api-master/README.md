# Newyork-Times-api

js file path changed before used your systems
