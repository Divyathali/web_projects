# node-mysql-express-crud

nodemon app.js || run test 

connect your Database and port numbers in .env file.

here .env file is not mentioned for privacy purpose.


