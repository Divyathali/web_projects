# Breakout_brick_games

<img  width="600" src="https://github.com/Divyathali/breakout_brick_games/blob/main/images/braekoutgames.png"/>
